package com.capgemini.doctors.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.PatientException;





public class TestDAO {
	
	static DoctorAppointmentDao docDAO;
	
	static DoctorAppointment docBean;
	
	@BeforeClass
	public static void beforeClass()
	{
		docDAO=new DoctorAppointmentDao();
		docBean=new DoctorAppointment();

	}
	
	@Test
	public void testAddCust()throws PatientException{
		
		docBean.setPatient_name("Shubham");
		docBean.setEmail("sv@gmail.com");
		docBean.setPhone_number("8015707783");
		docBean.setAge(23);
		docBean.setGender("Male");
		docBean.setProblem_name("ENT");
		
		int id=docDAO.addApppointment(docBean);
		assertTrue(id>0);
	}
	
	
	@Test
	public void testAddCust1() throws PatientException {

		assertNotNull(docDAO.addApppointment(docBean));

	}
	
	public void testAddCust2() throws PatientException {
		// increment the number next time you test for positive test case
		assertEquals(1009, docDAO.addApppointment(docBean));
	}
	
	@Test
	public void testById() throws PatientException {
		assertNotNull(docDAO.viewAppointment(1001));
	}
	
	

}
