package com.capgemini.doctors.test;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.doctors.exception.PatientException;
import com.capgemini.doctors.util.DBConnection;




public class TestDBConn {
	
	
	@Test
	public void TestConnection()throws PatientException{
		Connection con=DBConnection.getConnection();
		assertNotNull(con);
	}
	
	
	@Ignore
	@Test(expected=PatientException.class)
	public void TestConnectionFail()throws PatientException{
		Connection con=DBConnection.getConnection();
	}
	

}
