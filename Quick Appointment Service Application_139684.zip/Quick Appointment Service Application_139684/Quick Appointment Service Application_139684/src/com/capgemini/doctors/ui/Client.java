/*******************************************************************************************************
	 - Class Name		: 	Client
	 - Extends			: 	
	 - Implements		: 	
	 - Throws			: 	PatientException
	 - Author	      	: 	Shubham Vaya
	 - Creation Date	:	30/11/2017
	 - Description		: 	Interacts with the Patient
	 ********************************************************************************************************/


package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.PatientException;
import com.capgemini.doctors.service.DoctorAppointmentService;

public class Client {
	
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		DoctorAppointment docBean=new DoctorAppointment();
		DoctorAppointmentService service=new DoctorAppointmentService();
		int again;
		do
		{
		System.out.println("Choose the operation you want to perform:\n1.Book Doctor Appointment\n2.View Doctor Appointment\n3.Exit");
		int ch=scan.nextInt();
		
			switch(ch){
				case 1:
					System.out.println("Enter name of the patient : ");
					String PatName=scan.next();
					System.out.println("Enter Phone Number : ");
					String phNo=scan.next();
					System.out.println("Enter E-mail : ");
					String email=scan.next();
					System.out.println("Enter Age : ");
					int age=scan.nextInt();
					System.out.println("Enter Gender : ");
					String gender=scan.next();
					System.out.println("Enter Problem Name: ");
					String probName=scan.next();
					
					docBean.setPatient_name(PatName);
					docBean.setPhone_number(phNo);
					docBean.setEmail(email);
					docBean.setAge(age);
					docBean.setGender(gender);
					docBean.setProblem_name(probName);
					
					try {
						if(service.validateDetails(docBean)){
					int id=service.addApppointment(docBean);
					System.out.println("Appointment Added Successfully");
					System.out.println("Appointment ID: "+id);
				} }catch (PatientException e) {
					e.printStackTrace();
				}
				break;
				
				case 2:
					try{
						System.out.println("Enter the Appointment ID:");
						int id=scan.nextInt();
						System.out.println(service.viewAppointment(id));
						}catch(PatientException e){
						e.printStackTrace();
					}
					break;
				case 3:
					System.exit(0);
					break;
				default:
					System.out.println("enter valid choice!");
				}
			System.out.println("\n->Enter 1 for continue.\n->Enter 2 for exit");
			 again = scan.nextInt();
	}while(again==1);
	
		scan.close();
	}}