//------------------------  Quick Appointment Service Application --------------------------
/*******************************************************************************************************
	 - Class Name		: 	DoctorAppointment
	 - Extends			: 	
	 - Implements		: 	
	 - Throws			: 	
	 - Author	      	: 	Shubham Vaya
	 - Creation Date	:	30/11/2017
	 - Description		: 	Creates a Bean class for the Details
	 ********************************************************************************************************/


package com.capgemini.doctors.bean;

import java.util.Date;

public class DoctorAppointment {
	
	private int appointment_id;
	private String patient_name;
	private String phone_number;
	private Date date_of_appointment;
	private String email;
	private int age;
	private String gender;
	private String problem_name; 
	private String doctor_name;
	private String appointment_status;
	
	public DoctorAppointment() {
		super();
		
	}
	public DoctorAppointment(int appointment_id, String patient_name, String phone_number,
			Date date_of_appointment, String email, int age, String gender,
			String problem_name, String doctor_name, String appointment_status) {
		super();
		this.appointment_id = appointment_id;
		this.patient_name = patient_name;
		this.phone_number = phone_number;
		this.date_of_appointment = date_of_appointment;
		this.email = email;
		this.age = age;
		this.gender = gender;
		this.problem_name = problem_name;
		this.doctor_name = doctor_name;
		this.appointment_status = appointment_status;
	}
	public int getAppointment_id() {
		return appointment_id;
	}
	public void setAppointment_id(int appointment_id) {
		this.appointment_id = appointment_id;
	}
	public String getPatient_name() {
		return patient_name;
	}
	public void setPatient_name(String patient_name) {
		this.patient_name = patient_name;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public Date getDate_of_appointment() {
		return date_of_appointment;
	}
	public void setDate_of_appointment(Date date_of_appointment) {
		this.date_of_appointment = date_of_appointment;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getProblem_name() {
		return problem_name;
	}
	public void setProblem_name(String problem_name) {
		this.problem_name = problem_name;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public String getAppointment_status() {
		return appointment_status;
	}
	public void setAppointment_status(String appointment_status) {
		this.appointment_status = appointment_status;
	}

	
}
