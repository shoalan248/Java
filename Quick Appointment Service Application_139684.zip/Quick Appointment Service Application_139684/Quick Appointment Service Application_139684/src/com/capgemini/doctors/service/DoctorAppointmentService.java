//---------------------  Quick Appointment Service Application --------------------------
/*******************************************************************************************************
	 - Class Name		: 	DoctorAppointmentService
	 - Extends			: 	
	 - Implements		: 	IDoctorAppointmentService
	 - Throws			: 	
	 - Author	      	: 	Shubham Vaya
	 - Creation Date	:	30/11/2017
	 - Description		: 	Performs the validations on the Details
	 ********************************************************************************************************/

package com.capgemini.doctors.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.PatientException;


public class DoctorAppointmentService implements IDoctorAppointmentService {
	
	DoctorAppointmentDao docAptDao=new DoctorAppointmentDao(); 
	
	public int addApppointment(DoctorAppointment docBean)throws PatientException{
		int id=docAptDao.addApppointment(docBean);
		return id;
	}
	
	public String viewAppointment(int id) throws PatientException{
		String str=docAptDao.viewAppointment(id);
		return str;
	}
	
	public int validateId(int id)throws PatientException{
		int id1=docAptDao.validateId(id);
		return id1;
	}
	
	
	//------------------------  Quick Appointment Service Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	validateDetails()
	 - Input Parameters	:	DoctorAppointment docBean
	 - Return Type		:	boolean
	 - Throws			:  	
	 - Author			:	Shubham Vaya
	 - Creation Date	:	30/11/2017
	 - Description		:	Validating patient's details
	 ********************************************************************************************************/
	
	public boolean validateDetails(DoctorAppointment docBean) throws PatientException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating Employee's Name
		if(!(isValidName(docBean.getPatient_name()))) {
			validationErrors.add("\n Employee Name's 1st char should be in Uppercase and Should Be Alphabets  ! \n");
		}
		
		//Validating Contact Number
		if(!(isValidContactNumber(docBean.getPhone_number()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		//Validating Email Address
		if(!(isValidMail(docBean.getEmail()))){
			validationErrors.add("\n Email Address should be valid \n" );
		}
		String str=String.valueOf(docBean.getAge());
		//Validating Age
		if(!(isValidAge(str))){
			validationErrors.add("\n Age should be valid \n" );
		}
		
		
		//Validating Problem Name
		if(!(isValidProbName(docBean.getProblem_name()))){
			validationErrors.add("\n Give a Valid Problem Name \n");
		}
		
		if(!validationErrors.isEmpty())
			throw new PatientException(validationErrors +"");
		else{
			return true;
		}
		}
			

	public boolean isValidName(String Name){
		Pattern namePattern=Pattern.compile("^[A-Z][A-Za-z]{2,19}$");
		Matcher nameMatcher=namePattern.matcher(Name);
		return nameMatcher.matches();
	}
		
	public boolean isValidContactNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[1-9][0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
	}
	
	public boolean isValidMail(String email){
		Pattern mailPattern=Pattern.compile("^[a-z0-9._%+-]+@[a-z]+\\.[a-z]{2,6}$");
		Matcher mailMatcher=mailPattern.matcher(email);
		return mailMatcher.matches();
	}

	public boolean isValidAge(String age){
		Pattern mailPattern=Pattern.compile("^[0-9]{2}$");
		Matcher mailMatcher=mailPattern.matcher(age);
		return mailMatcher.matches();
	}
	
	public boolean isValidProbName(String probName){
		
		boolean state=false;
		if (probName.equals("Heart")){
			state=true;
		}
		else if (probName.equals("Gynecology")){
			state=true;
		}
		else if (probName.equals("Diabetes")){
			state=true;
		}
		else if (probName.equals("ENT")){
			state=true;
		}
		else if (probName.equals("Bone")){
			state=true;
		}
		else if (probName.equals("Dermatology")){
			state=true;
		}
		return state; 
	}
	

}

