//------------------------  Quick Appointment Service Application --------------------------
/*******************************************************************************************************
	 - Class Name		: 	DoctorAppointmentDao
	 - Extends			: 	
	 - Implements		: 	IDoctorAppointmentDao
	 - Throws			: 	
	 - Author	      	: 	Shubham Vaya
	 - Creation Date	:	30/11/2017
	 - Description		: 	Performs the operations chosen by the user
	 ********************************************************************************************************/




package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.PatientException;
import com.capgemini.doctors.util.DBConnection;



public class DoctorAppointmentDao implements IDoctorAppointmentDao {

	Logger log=Logger.getLogger(DoctorAppointmentDao.class);
	
	public DoctorAppointmentDao() {
		super();
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
			//------------------------  Quick Appointment Service Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	generateAppointmentId()
			 - Input Parameters	:	
			 - Return Type		:	int
			 - Throws			:  	
			 - Author			:	Shubham Vaya
			 - Creation Date	:	30/11/2017
			 - Description		:	Generating Appointment Id for the patient
			 ********************************************************************************************************/

	public int generateAppointmentId() {
		Connection con = null;
		String cmd = "select seq_appointment_id.nextval from dual";
		int id = 0;
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(cmd);
			rst.next();
			id = rst.getInt(1);

		} catch (Exception e) {
			log.warn("Sequence is not created");
			
		}
		return id;
	}
	
	//------------------------  Quick Appointment Service Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	addApppointment()
		 - Input Parameters	:	DoctorAppointment docBean
		 - Return Type		:	int
		 - Throws			:  	PatientException
		 - Author			:	Shubham Vaya
		 - Creation Date	:	30/11/2017
		 - Description		:	Adding Appointment of the patient
		 ********************************************************************************************************/
	@Override
	public int addApppointment(DoctorAppointment docBean)
			throws PatientException {
		Connection con = null;
		PreparedStatement pstmt = null;
		String cmd = "insert into doctor_appointment(appointment_id,patient_name,phone_number,date_of_appointment,email,age,gender,problem_name,doctor_name,appointment_status) values(?,?,?,sysdate+1,?,?,?,?,?,?)";
		int id = 0;
		String status = apt_status(docBean.getProblem_name());
		String doc_name = assign_doc_name(docBean.getProblem_name());
		try {
			con = DBConnection.getConnection();
			id = generateAppointmentId();

			pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, docBean.getPatient_name());
			pstmt.setString(3, docBean.getPhone_number());

			pstmt.setString(4, docBean.getEmail());
			pstmt.setInt(5, docBean.getAge());
			pstmt.setString(6, docBean.getGender());
			pstmt.setString(7, docBean.getProblem_name());
			pstmt.setString(8, doc_name);
			pstmt.setString(9, status);

			pstmt.executeUpdate();
			log.info("Insertion Successful");
		} catch (SQLException e) {
			
			log.debug("Check the insert query");
			throw new PatientException("Unable to insert");
		}

		return id;
	}

	
	//------------------------  Quick Appointment Service Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	apt_status()
	 - Input Parameters	:	String probName
	 - Return Type		:	String
	 - Throws			:  	
	 - Author			:	Shubham Vaya
	 - Creation Date	:	30/11/2017
	 - Description		:	Getting the Appointment status of the patient
	 ********************************************************************************************************/

	public String apt_status(String probName) {

		String state = "Disapproved";
		if (probName.equals("Heart")) {
			state = "Approved";
		} else if (probName.equals("Gynecology")) {
			state = "Approved";
		} else if (probName.equals("Diabetes")) {
			state = "Approved";
		} else if (probName.equals("ENT")) {
			state = "Approved";
		} else if (probName.equals("Bone")) {
			state = "Approved";
		} else if (probName.equals("Dermatology")) {
			state = "Approved";
		}
		return state;
	}

	
	//------------------------  Quick Appointment Service Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	assign_doc_name()
		 - Input Parameters	:	String probName
		 - Return Type		:	String
		 - Throws			:  	
		 - Author			:	Shubham Vaya
		 - Creation Date	:	30/11/2017
		 - Description		:	Assigning the Doctor's name for the Appointment
		 ********************************************************************************************************/

	
	public String assign_doc_name(String probName) {

		String name = null;
		if (probName.equals("Heart")) {
			name = "Dr. Brijesh Kumar";
		} else if (probName.equals("Gynecology")) {
			name = "Dr. Sharda Singh";
		} else if (probName.equals("Diabetes")) {
			name = "Dr. Heena Khan";
		} else if (probName.equals("ENT")) {
			name = "Dr. Paras Mal";
		} else if (probName.equals("Bone")) {
			name = "Dr. Renuka Kher";
		} else if (probName.equals("Dermatology")) {
			name = "Dr. Kanika Kapoor";
		}
		return name;
	}
	
	//------------------------  Quick Appointment Service Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	validateId()
	 - Input Parameters	:	int id
	 - Return Type		:	int
	 - Throws			:  	
	 - Author			:	Shubham Vaya
	 - Creation Date	:	30/11/2017
	 - Description		:	Validating the Appointment Id
	 ********************************************************************************************************/
	
	@Override
	public int validateId(int id) throws PatientException {
		Connection con = null;
		String qry = "select appointment_id from doctor_appointment where appointment_id="
				+ id;
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			if (rst.next())
				id = rst.getInt(1);
			else
				id = -1;
			con.close();
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new PatientException("Id is invalid");

		}

		return id;
	}
	
	//------------------------  Quick Appointment Service Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	viewAppointment()
		 - Input Parameters	:	id
		 - Return Type		:	String
		 - Throws			:  	PatientException
		 - Author			:	Shubham Vaya
		 - Creation Date	:	30/11/2017
		 - Description		:	Viewing the Appointment of the patient
		 ********************************************************************************************************/

	@Override
	public String viewAppointment(int id) throws PatientException {
		Connection con = null;
		DoctorAppointment docBean = new DoctorAppointment();
		int ch = validateId(id);
		String cmd = "select patient_name,appointment_status,doctor_name,date_of_appointment from doctor_appointment where appointment_id="
				+ id;

		try {
			if (ch != -1) {

				con = DBConnection.getConnection();
				Statement stmt = con.createStatement();
				ResultSet rst = stmt.executeQuery(cmd);
				System.out.println("Appointment Details are: ");
				rst.next();
				docBean.setPatient_name(rst.getString(1));
				docBean.setAppointment_status(rst.getString(2));
				docBean.setDoctor_name(rst.getString(3));
				docBean.setDate_of_appointment(rst.getDate(4));
				log.info("Selection Successful");
			}

		} catch (SQLException e) {
			log.debug("Check the Employee ID, Result set object");
			log.warn("Invalid Employee ID");
			log.error(e.getMessage());
			throw new PatientException("Record Retrieval Failed");
		}
		return ("Patient Name:" + docBean.getPatient_name()
				+ "\nAppointment Status: " + docBean.getAppointment_status()
				+ "\nDoctor Name: " + docBean.getDoctor_name()
				+ "\nAppointment Date: " + docBean.getDate_of_appointment());
	}

}
