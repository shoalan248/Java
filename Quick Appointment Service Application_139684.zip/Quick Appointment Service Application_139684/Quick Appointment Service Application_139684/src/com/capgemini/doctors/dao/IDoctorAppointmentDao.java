package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.PatientException;

public interface IDoctorAppointmentDao {
	
	public int addApppointment(DoctorAppointment docBean)throws PatientException;
	public String viewAppointment(int id) throws PatientException;
	public int validateId(int id)throws PatientException;

}
