create table doctor_appointment(appointment_id NUMBER(4) primary key,patien
t_name varchar2(20),phone_number varchar2(10),date_of_appointment date,email var
char2(50),age number(2),gender varchar2(6),problem_name varchar2(25),doctor_name
 varchar2(25),appointment_status varchar2(11));

Table created.

create sequence seq_appointment_id start with 1001;

Sequence created.

