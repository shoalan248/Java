package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.emp.bean.CustomerBean;
import com.emp.bean.MobileBean;
import com.emp.exception.MobileException;
import com.emp.util.DBConnection;

public class CustomerDaoImpl implements CustomerDao
{
	Scanner sc = new Scanner(System.in);
	
	Logger logger = Logger.getLogger(CustomerDaoImpl.class);
	
	public CustomerDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	public int generateEmployeeId()
	{
		int id=0;
		Connection  con = null;
		String str= "select purchaseid_seq.nextval from dual";
		try 
		{
			logger.info("connecting to database for generating id..");
			con=DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);

			logger.info("id generated..\n");
		}
		catch (Exception e) 
		{
			logger.info("id can not be generated..\n");
			System.out.println("id can not generated.try again!");
		}
		return id;
	}
	
	@Override
	public int addCustomer(CustomerBean bean) throws MobileException
	{
		int id=0;
		Connection con= null;
	
		String cmd="insert into purchasedetails values(?,?,?,?,sysdate,?)";
		
		try 
		{
			logger.debug("connecting to database for adding purchase details of customer..");
			con=DBConnection.getConnection();
			id=generateEmployeeId();
	
			PreparedStatement ps = con.prepareStatement(cmd);
			
			ps.setInt(1,id);
			ps.setString(2,bean.getCname());
			ps.setString(3, bean.getMailid());
			ps.setString(4, bean.getPhoneno());
			ps.setInt(5, bean.getMobileid());
			
			int n=ps.executeUpdate();
			System.out.println(n);
			if(n==0)
			{
				logger.error("exception while adding database..\n");
				throw new MobileException("unable to insert");
			}
			else
			{
				logger.debug("purchase details added, updating mobiles table..");
				String cmd1="update mobiles set quantity = quantity-1 where mobileid = ?";
				PreparedStatement ps1=con.prepareStatement(cmd1);
				ps1.setInt(1,bean.getMobileid());
				int i= ps1.executeUpdate();
				System.out.println(i);
				logger.info("mobiles table updated..\n");
			}
			
		}
		catch (Exception e) 
		{
			logger.error("exception while adding details..\n");
			throw new MobileException("mobile id not found");
		} 
		return id;
	}

	@Override
	public int deleteMob(int deleteId) throws MobileException 
	{
		Connection con= null;
		Statement stmt =null;
		
		
		try 
		{
			logger.debug("connecting to database for deleting details of mobile..");
			con=DBConnection.getConnection();
			String cmd="delete from mobiles where mobileid ="+ deleteId;
			String cmd1="delete from purchasedetails where mobileid ="+ deleteId;
			
			stmt =con.createStatement();
			int n= stmt.executeUpdate(cmd1);
			if(n==0)
			{
				logger.info("details deleted from purchasedetails table..");
				int i= stmt.executeUpdate(cmd);
				if(i==0)
				{
					logger.error("exception while deleting details..\n");
					throw new MobileException("id not found in mobile details");
				}
			}
		}
		catch (MobileException e) 
		{
			logger.error("exception while deleting details..\n");
			throw new MobileException("id not found in mobile details");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return deleteId;
	}

	@Override
	public List<MobileBean> viewAllMob() throws MobileException
	{
		Connection con= null;
		Statement stmt =null;
		
		List<MobileBean> employeeList = new ArrayList<MobileBean>();
		try {
			logger.debug("connecting to database for viewing details of mobile..");
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String cmd = "select * from mobiles";
			PreparedStatement ps = null;
			ResultSet resultset = null;

			ps = con.prepareStatement(cmd);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				MobileBean bean1 = new MobileBean();
				bean1.setMobileid(resultset.getInt(1));
				bean1.setName(resultset.getString(2));
				bean1.setPrice(resultset.getInt(3));
				bean1.setQuantity(resultset.getString(4));
				
				employeeList.add(bean1);
				}
			logger.info("details fetched from mobiles..\n");
		}
		catch (SQLException e) {
			logger.error("exception while fetching details..\n");
			System.out.println(e);

		}
		return employeeList;

	}

	@Override
	public MobileBean viewMobById(int viewId) throws MobileException
	{
		Connection con= null;
		Statement stmt =null;
		MobileBean bean= new MobileBean();
		
		try {
			logger.debug("connecting to database for viewing details of mobile by id..");
			con=DBConnection.getConnection();
			String cmd="select mobileid,name,price,quantity from mobiles where mobileid ="+ viewId;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
			 if(result.next())
				{
				 	bean.setMobileid(result.getInt(1));
					bean.setName(result.getString(2));
					bean.setPrice(result.getInt(3));
					bean.setQuantity(result.getString(4));
					logger.info("details fetched from mobiles table..\n");	
				}
			 else
			 {
				 logger.error("exception while fetching details..\n");
				 throw new MobileException("Id not found!");
			 }
		}
		 catch (SQLException e) 
		{
			System.out.println("database error!");
		}
		return bean;	
	}

	@Override
	public List<MobileBean> searchByRange(int min, int max)
			throws MobileException 
	{
		Connection con= null;
		Statement stmt =null;
		
		List<MobileBean> employeeList = new ArrayList<MobileBean>();
		try {
			logger.debug("connecting to database for searching mobile by range..");
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String cmd = "select * from mobiles where price between "+min+ " and " +max;
			PreparedStatement ps = null;
			ResultSet resultset = null;

			ps = con.prepareStatement(cmd);
			resultset = ps.executeQuery();
	
			while (resultset.next()) {
				MobileBean bean1 = new MobileBean();
				bean1.setMobileid(resultset.getInt(1));
				bean1.setName(resultset.getString(2));
				bean1.setPrice(resultset.getInt(3));
				bean1.setQuantity(resultset.getString(4));
				
				employeeList.add(bean1);

			}
			if(employeeList.isEmpty())
					{
						logger.error("exception while fetching details..\n");
						throw new MobileException("No mobiles found between "+min +" and "+max);
					}
			else
			{
				logger.info("details fetched from mobiles table..\n");
			}
		} 
		catch (SQLException e) {
			System.out.println(e);

		}
		return employeeList;
	}
}
