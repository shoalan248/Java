package com.emp.bean;

import java.util.Date;

public class CustomerBean
{
	private int purchaseid;
	private String cname;
	private String mailid;
	private String phoneno;
	private Date purchasedate;
	private int mobileid;
	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	@Override
	public String toString() {
		return "purchaseid       :  " + purchaseid +"\n"
				+ " cname        :" + cname+"\n"
				+ " mailid       :" + mailid +"\n"
				+ " phoneno      :" + phoneno+"\n"
				+ " purchasedate :" + purchasedate +"\n"
				+ " mobileid     :" + mobileid +"\n";
	}
}
