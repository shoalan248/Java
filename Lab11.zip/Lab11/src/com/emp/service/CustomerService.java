package com.emp.service;
import java.util.List;

import com.emp.bean.CustomerBean;
import com.emp.bean.MobileBean;
import com.emp.exception.MobileException;

public interface CustomerService 
{               
	public int addCustomer(CustomerBean bean) throws MobileException; 
	public int deleteMob(int deleteId) throws MobileException;
	public List<MobileBean> viewAllMob() throws MobileException;
	public MobileBean viewMobById(int empid) throws MobileException;
	public List<MobileBean> searchByRange(int min,int max) throws MobileException;
	public boolean validateName(String name) throws MobileException;
	public boolean validatePhone(String phone) throws MobileException ;
	public boolean validateEmail(String email) throws MobileException;
	boolean validateDetails(CustomerBean bean) throws MobileException;
	
}
