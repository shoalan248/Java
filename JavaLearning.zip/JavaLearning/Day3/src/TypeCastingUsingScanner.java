import java.util.Scanner;

public class TypeCastingUsingScanner {
	
	public static void main(String args[]){
	System.out.println("Enter the no of employees");
	Scanner empSc=new Scanner(System.in);
	int n=empSc.nextInt();
	InheritEmp emps[]=new InheritEmp[n];
	
	for(int i=0;i<n;i++)
	{
		System.out.println("Enter the employee's type: \n1.Sales Manager,\n2.Wage Employee,\n3.Employee");
		int type=empSc.nextInt();
		switch(type)
		{

		case 1:
			System.out.print("Enter the Emp ID: ");
			int empid=empSc.nextInt();
			
			System.out.print("Enter the Emp Name: ");
			String empName=empSc.next();

			System.out.print("Enter the Emp sal: ");
			float empSal=empSc.nextFloat();
			
			System.out.print("Enter the Emp No of hours: ");
			int empNoOfHrs=empSc.nextInt();
			
			System.out.print("Enter the Rate per hour: ");
			int empRatePerHr=empSc.nextInt();
			
			System.out.print("Enter the sales: ");
			int empSales=empSc.nextInt();
			
			System.out.print("Enter the Commisiion: ");
			float empComm=empSc.nextFloat();
			emps[i]=new SalesMgr(empid,empName,empSal,empNoOfHrs,empRatePerHr,empSales,empComm);
			break;


				
		case 2:
			System.out.print("Enter the Emp ID: ");
			empid=empSc.nextInt();
			
			System.out.print("Enter the Emp Name: ");
			empName=empSc.next();

			System.out.print("Enter the Emp sal: ");
			empSal=empSc.nextFloat();
			
			System.out.print("Enter the Emp No of hours: ");
			empNoOfHrs=empSc.nextInt();
			
			System.out.print("Enter the Rate per hour: ");
			empRatePerHr=empSc.nextInt();	
			emps[i]=new WageEmp(empid,empName,empSal,empNoOfHrs,empRatePerHr);
			break;
		
		
		case 3:
			System.out.print("Enter the Emp ID: ");
			empid=empSc.nextInt();
			
			System.out.print("Enter the Emp Name: ");
			empName=empSc.next();

			System.out.print("Enter the Emp sal: ");
			empSal=empSc.nextFloat();
			emps[i]=new InheritEmp(empid,empName,empSal);
			break;
			
	}
		System.out.println("Employee info : "+emps[i].dispEmpInfo());
		System.out.println("Annual Salary : "+emps[i].calEmpAnnualSal()+"\n");
	}
	
}
}