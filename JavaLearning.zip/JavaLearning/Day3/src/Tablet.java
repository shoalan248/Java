public class Tablet extends Medicine{
		String type;
		public Tablet()
		{}
		public Tablet(String medName,String comName,String expDate,int price,String type)
		{
			super(medName,comName,expDate,price);
			this.type=type;
			
		}
		@Override
		public String dispMedicines()
		{
			super.dispMedicines();
			return (super.dispMedicines()+"\nStore it in cool and dry place");
		}

}
