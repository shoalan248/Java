public class InheritEmp {

		private int empId;
		private String empName;
		private float empSal;
		
		public InheritEmp()
		{}
		
		public InheritEmp(int empId,String empName,float empSal)
		{
			this.empId=empId;
			this.empName=empName;
			this.empSal=empSal;
		}
		public String dispEmpInfo()
		{
			return "\nempId=" +empId+",\nempName=" +empName+",\nBasic empSal=" +empSal;
		}
		public float calEmpAnnualSal()
		{
			return empSal*12;
		}

	}
