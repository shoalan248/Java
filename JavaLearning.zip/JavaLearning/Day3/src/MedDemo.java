import java.util.Scanner;
public class MedDemo {
	public static void main(String args[])
	{
	String typ="";
	Scanner med=new Scanner(System.in);
	System.out.println("Enter the size");
	int type=med.nextInt();
	Medicine meds[]=new Medicine[type];
	
	for(int i=0;i<meds.length;i++)
	{
		System.out.println("Enter the Medicine's type: \n1.Tablet,\n2.Ointment,\n3.Syrup");
		
		switch(type)
		{

		case 1:
			System.out.print("Enter the Medicine's Name: ");
			String medName=med.next();
			
			System.out.print("Enter the Company's Name: ");
			String comName=med.next();

			System.out.print("Enter the Expiry Date: ");
			String expDate=med.next();
			
			System.out.print("Enter the Price: ");
			int price=med.nextInt();
			
			typ="Tablet";
			meds[i]=new Tablet(medName,comName,expDate,price,typ);
			break;


				
		case 2:
			System.out.print("Enter the Medicine's Name: ");
			medName=med.next();
			
			System.out.print("Enter the Company's Name: ");
			comName=med.next();

			System.out.print("Enter the Expiry Date: ");
			expDate=med.next();
			
			System.out.print("Enter the Price: ");
			price=med.nextInt();
			
			typ="Ointment";
			meds[i]=new Ointment(medName,comName,expDate,price,typ);
			break;
		
		
		case 3:
			System.out.print("Enter the Medicine's Name: ");
			medName=med.next();
			
			System.out.print("Enter the Company's Name: ");
			comName=med.next();

			System.out.print("Enter the Expiry Date: ");
			expDate=med.next();
			
			System.out.print("Enter the Price: ");
			price=med.nextInt();
			
			typ="Syrup";
			meds[i]=new Syrup(medName,comName,expDate,price,typ);
			break;
			
	}
		System.out.println("Medicine's Info: "+meds[i].dispMedicines());
	}
	med.close();	
}
}
