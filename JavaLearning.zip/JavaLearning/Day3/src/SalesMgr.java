public class SalesMgr extends WageEmp {
		int sales;
		float commission;
		
		public SalesMgr()
		{	
			super();// As we can't access the parent class' private members so we are passing it by calling super();ie it sends these values to the parent class
		}
		
		public SalesMgr(int empId,String empName,float empSal,int noOfHrs, int ratePerHrs,int sales,float commission) {
			super(empId,empName,empSal,noOfHrs,ratePerHrs);
			this.sales = sales;
			this.commission = commission;
		}
		public float calEmpAnnualSal(){ //This method is overridden as the name of fn. is same as fn in inheritEmp
		//public float calcWageEmpAnnSal(){
			return (super.calEmpAnnualSal())+(sales*(commission/100)*22*12);
		}
		public String dispEmpInfo()
		{
			return (super.dispEmpInfo()+"\nSales:"+sales+"\nCommission:"+commission);
		}
	}




