public class TypeCastingFromUser {
		public static void main(String args[])
		{
			InheritEmp emps[]=new InheritEmp[6];
			emps[0]=new InheritEmp(101,"abc",1000.0f);
			emps[1]=new WageEmp(102,"sg",2000.0f,1,1000);
			emps[2]=new SalesMgr(103,"dg",3000.0f,2,200,2,2000);
			emps[3]=new InheritEmp(104,"gf",4000.0f);
			emps[4]=new WageEmp(105,"df",5000.0f,3,3000);
			emps[5]=new SalesMgr(106,"zc",6000.0f,4,4000,4,4000);
			
		
			for(int i=0;i<emps.length;i++)
			{
				if(emps[i] instanceof SalesMgr)
				{
				System.out.println("Sales Manager info : "+emps[i].dispEmpInfo());
				System.out.println("Annual Salary : "+emps[i].calEmpAnnualSal());
				}
				else if(emps[i] instanceof WageEmp)
				{
					System.out.println("Wage Employee info : "+emps[i].dispEmpInfo());
					System.out.println("Annual Salary : "+emps[i].calEmpAnnualSal());
				}
				else
				{
					System.out.println("Employee info : "+emps[i].dispEmpInfo());
					System.out.println("Annual Salary : "+emps[i].calEmpAnnualSal());
				}
			}
		}
}