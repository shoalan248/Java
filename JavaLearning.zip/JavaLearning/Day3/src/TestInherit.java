public class TestInherit {
	public static void main(String args[]){
		InheritEmp shubh=new InheritEmp(123,"Shubh",50000.0f);
		WageEmp shubham=new WageEmp(456,"Shubham",40000.0f,8,2000);
		System.out.println(""+shubh.dispEmpInfo());
		System.out.println(""+shubh.calEmpAnnualSal());
		
		System.out.println(""+shubham.dispEmpInfo());
		System.out.println(""+shubham.calEmpAnnualSal());//As it is calling an overridden function.
		
		InheritEmp vaya=new WageEmp(456,"vaya",35000.0f,8,2000);//Here static type (ie LHS)is InheritEmp and Dynamic type(ie RHS)
		/* It is UPCASTING as it is coverting child type to parent type. It is IMPLICIT TYPE CASTING */
		
		System.out.println(""+vaya.dispEmpInfo());
		System.out.println(""+vaya.calEmpAnnualSal());// It is called dynamic binding as calEmpAnnualSal() is both in the parent class as well as in the inherited class.
		// So the JVM will call the calEmpAnnualSal() of the child class.

		SalesMgr shu=new SalesMgr(456,"Shu",30000.0f,8,2000,3000,12.6f);
		// U can even try this: WageEmp shu=new WageEmpMgr(456,"Shu",30000.0f,8,2000,3000,12.6f);
		System.out.println(""+shu.dispEmpInfo());
		System.out.println(""+shu.calEmpAnnualSal());
	}

}
