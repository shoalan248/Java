public class Person {
	// Related to person.java and varDate.java

	enum Gender
	{
		M,F,Male,Female;
	}

		private String panNo;
		private String perName;
		private float perSal;
		Gender perGender;
		varDate personDOB;
		
		public Person()
		{
			panNo="unknown";
			perName="unknown";
			perSal=0.0f;
			personDOB=new varDate();
		
		}
		public Person(String panNo,String perName,float perSal,varDate personDOB)
		{
			this.panNo=panNo;
			this.perName=perName;
			this.perSal=perSal;
			this.personDOB=personDOB;
		}
		
		
		public Person(String panNo, String perName, float perSal, Gender perGender,
				varDate personDOB) {
			this.panNo = panNo;
			this.perName = perName;
			this.perSal = perSal;
			this.perGender = perGender;
			this.personDOB = personDOB;
		}
		public String toString()
		{
			return "Person [panNo=" +panNo+ ",\nperName=" +perName+ ",\nperSal="+perSal+",\nperGender" +perGender+ ",\npersonDOB="+personDOB.dispDate()+"]";
			
		}

	}

