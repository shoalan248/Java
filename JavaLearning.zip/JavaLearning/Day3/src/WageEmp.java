public class WageEmp extends InheritEmp{
	int noOfHrs;
	int ratePerHrs;
	
	public WageEmp()
	{	
		super();// As we can't access the parent class' private members so we are passing it by calling super();ie it sends these values to the parent class
	}
	
	public WageEmp(int empId,String empName,float empSal,int noOfHrs, int ratePerHrs) {
		super(empId,empName,empSal);
		this.noOfHrs = noOfHrs;
		this.ratePerHrs = ratePerHrs;
	}
	
	public String dispEmpInfo()
	{
		return (super.dispEmpInfo()+"\nNo. Of Hrs:"+noOfHrs+"\nRate Per Hr:"+ratePerHrs);
	}
	public float calEmpAnnualSal(){ //This method is overridden as the name of fn. is same as fn in inheritEmp
	//public float calcWageEmpAnnSal(){
		return (super.calEmpAnnualSal())+(noOfHrs*ratePerHrs*22*12);
	}
}
