public class Ointment extends Medicine{
	String type;
		public Ointment()
		{}
		public Ointment(String medName,String comName,String expDate,int price,String type)
		{
			super(medName,comName,expDate,price);
			this.type=type;
		}
		
		
		public String dispMedicines()
		{
			super.dispMedicines();
			return (super.dispMedicines()+"\nFor external use only");
		}
	}