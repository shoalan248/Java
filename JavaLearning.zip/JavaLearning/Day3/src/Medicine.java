public class Medicine {
		private String medName;
		private String comName;
		private String expDate;
		private int price;
		public Medicine()
		{}
		public Medicine(String medName,String comName,String expDate, int price)
		{
			this.medName=medName;
			this.comName=comName;
			this.expDate=expDate;
			this.price=price;
		}
		
		public String dispMedicines()
		{
			return ("\nMedicinde Name : "+medName+"\nCompany Name : "+comName+ "\nExpiry Date : "+expDate+"\nPrice : "+price);
		}
}
