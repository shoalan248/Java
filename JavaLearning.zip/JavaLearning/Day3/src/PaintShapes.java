
public class PaintShapes {
	public static void main(String args[])
	{
		Shape shape1=new Circle(3);
		Shape shape2=new Sphere(3);
		shape1.drawShape();
		shape2.drawShape();
		System.out.println("Area of Circle: "+shape1.calcArea());
		System.out.println("Area of Sphere: "+shape2.calcArea());
		System.out.println("Circumference of Circle: "+shape1.calcVolume());
		System.out.println("Circumference of Sphere: "+shape2.calcVolume());
	}

}