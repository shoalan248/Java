public class Syrup extends Medicine{
	String type;
	public Syrup()
	{}
	public Syrup(String medName,String comName,String expDate,int price,String type)
	{
		super(medName,comName,expDate,price);
		this.type=type;
	}
	
	@Override
	public String dispMedicines()
	{
		
		return (super.dispMedicines()+"\nShake well before use");
	}
}