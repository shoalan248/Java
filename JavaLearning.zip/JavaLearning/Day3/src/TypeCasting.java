public class TypeCasting {
	public static void main(String args[])
	{
		InheritEmp e1= null;
		e1= new InheritEmp(123,"abc",450.0f);
		WageEmp e2= new WageEmp(234,"bcd",550.0f,4,50);
		SalesMgr e3= new SalesMgr(345,"cde",650.0f,5,60,1,1);
		InheritEmp e4= new WageEmp(456,"def",750.0f,6,70);
		InheritEmp e5= new SalesMgr(556,"def",850.0f,6,70,2,2);
		WageEmp e6= new SalesMgr(656,"def",750.0f,6,70,3,3);
		e2=(WageEmp)e4;
		System.out.println(e2.calEmpAnnualSal());
/*		e2=(WageEmp)e1;	//This can not be type casted as it is changing parent into child which isn't possible 
		System.out.println(e2.calEmpAnnualSal());
*/		if(e1 instanceof InheritEmp)
		{
			System.out.println("yes e1 is emp");
		}
		else
		{
			System.out.println("no e1 is not emp");
		}
		if(e1 instanceof SalesMgr)
		{
			System.out.println("yes e1 is SalesMgr");
		}
		else
		{
			System.out.println("no e1 is not SalesMgr");
		}
	}
}
