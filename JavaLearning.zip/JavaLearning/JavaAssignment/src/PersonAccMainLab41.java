import java.util.Scanner;

public class PersonAccMainLab41 {
	public static void main(String args[]){
		AccountLab41 smith=new AccountLab41();
		AccountLab41 kathy=new AccountLab41();
		
		smith.setName("Smith");
		smith.setAge(21.0f);
		smith.setBalance(2000.0);
		kathy.setName("Kathy");
		kathy.setAge(22.0f);
		kathy.setBalance(3000.0);
		
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter The amount to be Deposited: ");
		double dpst=scan.nextDouble();
		smith.deposit(dpst);
		
		System.out.println("Enter The amount to be Withdrawn: ");
		double wDraw=scan.nextDouble();
		kathy.withdraw(wDraw);
	scan.close();
	}

}
