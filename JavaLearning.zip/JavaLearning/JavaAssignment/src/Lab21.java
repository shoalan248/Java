
public class Lab21 {
	public static void main(String[] args)
	{
		System.out.println("Personal Details");
		System.out.println("\n______________________\n");
		System.out.println("First Name: Divya\nLast Name:Bharathi\nGender:F\nAge:20\nWegith:85.55");
	}

}
