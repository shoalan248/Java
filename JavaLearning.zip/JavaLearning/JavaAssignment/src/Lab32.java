import java.util.Scanner;


public class Lab32 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str=scan.next();
		boolean state=true;
		for(int i=0;i<str.length();i++)
		{
			if(state==true)
			{
				if(str.charAt(i+1)>str.charAt(i))
				{
					state=true;
				}
				else
				{
					state=false;
				}
			}
			else
			{
				state=false;
			}
		}
		if(state==true)
			System.out.println("The String is Positive");
		else
			System.out.println("The String is Negative");
		scan.close();
		
	}

}
