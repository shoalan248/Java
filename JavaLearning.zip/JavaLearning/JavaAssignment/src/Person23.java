
public class Person23 {
	String FirstName;
	String LastName;
	char Gender;
	public Person23() {
		super();
		
	}
	public Person23(String firstName, String lastName, char gender) {
		super();
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public String dispPerDetails()
	{
		return "\nFirst Name: "+FirstName+"\nLast Name: "+LastName+"\nGender: "+Gender;
	}
	

}
