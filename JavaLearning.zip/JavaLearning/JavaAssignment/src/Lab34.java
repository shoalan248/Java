import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Lab34 {
	public static void main(String[] args) {
		System.out.println("______Enter the first date_____ ");
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a Day: ");
		int day1 = scan.nextInt();
		System.out.println("Enter a Month: ");
		int mon1 = scan.nextInt();
		System.out.println("Enter a Year: ");
		int yr1 = scan.nextInt();
		LocalDate date1 = LocalDate.of(yr1, mon1, day1);
		
		System.out.println("______Enter the second date_____ ");
		System.out.println("Enter a Day: ");
		int day2 = scan.nextInt();
		System.out.println("Enter a Month: ");
		int mon2 = scan.nextInt();
		System.out.println("Enter a Year: ");
		int yr2 = scan.nextInt();
		LocalDate date2 = LocalDate.of(yr2, mon2, day2);
		Period per = Period.between(date2, date1);
		System.out.println("The difference is :" + per.getYears() + "-Years "
				+ per.getMonths() + "-Months " + per.getDays() + "-Days ");
		scan.close();
	}
}
