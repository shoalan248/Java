
public class PersonMain23 {
	public static void main(String args[])
	{
		Person23 per1=new Person23("Alankrita","Singh",'F'); 
		System.out.println(per1.dispPerDetails());
	}

}
