import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class LabMain37 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter your dob: ");
		String dob=scan.next();
		
		DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate perDob=LocalDate.parse(dob,myFormat);
		
		LabClass37 perInfo=new LabClass37("Alankrita","Singh",'F',perDob); 
		System.out.println("Age as of today : "+perInfo.calcAge(perDob)+"\n"+perInfo.mergeName()+"\n"+perInfo.dispPerDetails());
		scan.close();
		}

}