
public class SavAccMainLab42 extends AccountParentLab42{
	final double minBalance=500;
	
	
	public SavAccMainLab42() {
		super();
	}


	public SavAccMainLab42(String accHolder, long accNum, double balance)
	{
		super(accHolder, accNum, balance);
	}


	
	public void withdraw(double amt)
	{
		balance=balance-amt;
		if(balance>=minBalance&&balance>=amt)
		{
		System.out.println(tostring());
		}
		else
		{
			System.out.println("Insufficient Balance");
		}
	}
}
