import java.util.Scanner;
public class PersonMainlab25 {

		public static void main(String args[]){
		
		Scanner scan1=new Scanner(System.in);
		System.out.println("Enter the Phone number:");
		long number=scan1.nextLong();
		Person25 per1=new Person25("Alankrita","Singh",number,Gender.F);
		
		
		System.out.println("Person's Details:\n"+per1.dispPerDetails());
		scan1.close();
		}
	}