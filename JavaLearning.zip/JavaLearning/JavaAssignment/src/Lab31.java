import java.util.Scanner;

public class Lab31 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out
				.println("Select any of the following choices:\n1.Add the String\n2.Replace Odd position with #\n3.Remove duplicate Characters\n4.Change odd Characters to upercase");
		int choice = scan.nextInt();
		System.out.println("Enter a String:");
		String str = scan.next();
		StringBuilder sb = new StringBuilder(str);

		switch (choice) {
		case 1:
			System.out.println(str.concat(str));
			break;

		case 2:
			for (int i=1; i <=str.length(); i++){
		        if (i % 2 == 0){
		          str = str.substring(0,i-1) + "#" + str.substring(i, str.length());
		        }
			}
			System.out.println("The replaced String is :"+str);			
			break;
			
		case 3:
			for (int i=0; i < sb.length(); i++){
				for (int j=i+1; j < sb.length(); j++){
			
		        if (sb.charAt(i)==sb.charAt(j)){
		        	
		          sb.deleteCharAt(j);
		        }
			}
			}
			System.out.println("The updated String is "+sb);
			break;
			
		case 4:
			for (int i=0; i < str.length(); i++){
		        if (i % 2 != 0){
		        	 str = str.substring(0,i-1) + str.substring(i-1,i).toUpperCase() + str.substring(i, str.length());
		        }
			}
			System.out.println("The replaced String is :"+str);
			break;


		}
		scan.close();

	}

}
