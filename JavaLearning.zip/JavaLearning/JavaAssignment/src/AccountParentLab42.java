public abstract class AccountParentLab42 {
		String accHolder;
		long accNum;
		double balance;


		

		public AccountParentLab42() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
		
		public AccountParentLab42(String accHolder, long accNum, double balance)
		{
			
			this.accHolder = accHolder;
			this.accNum = accNum;
			this.balance = balance;
		}



		public String getAccHolder() {
			return accHolder;
		}



		public void setAccHolder(String accHolder) {
			this.accHolder = accHolder;
		}



		public long getAccNum() {
			return accNum;
		}



		public void setAccNum(long accNum) {
			this.accNum = accNum;
		}



		public double getBalance() {
			return balance;
		}



		public void setBalance(double balance) {
			this.balance = balance;
		}

		
		public abstract void withdraw(double amt);
		

		public String tostring(){
			return ("\nAccount Number: "+(long)Math.floor(Math.random()*9_000_000_000L)+"\nAccount Holder: "+accHolder+"\nBalance: "+balance);
		}
}
