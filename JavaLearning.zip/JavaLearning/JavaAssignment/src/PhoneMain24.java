import java.util.Scanner;

public class PhoneMain24 {

	public static void main(String args[]){
	
	Scanner scan1=new Scanner(System.in);
	System.out.println("Enter the Phone number:");
	long number=scan1.nextLong();
	Lab24 per1=new Lab24("Alankrita","Singh",number,'F');
	
	
	System.out.println("Person's Details:\n"+per1.dispPerDetails());
	scan1.close();
	}
}
