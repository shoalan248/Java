import java.util.Scanner;

public class SavCurrMainLab42 {

		public static void main(String args[]){
			SavAccMainLab42 smith=new SavAccMainLab42();
			CurrentAccLab42 kathy=new CurrentAccLab42();
			
			smith.setAccHolder("Smith");
			smith.setAccNum(123456789);
			smith.setBalance(2000.0);
			kathy.setAccHolder("Kathy");
			kathy.setAccNum(987654321);
			kathy.setBalance(3000.0);
			
			Scanner scan=new Scanner(System.in);
			
			
			System.out.println("Enter The amount to be Withdrawn: ");
			double sDraw=scan.nextDouble();
			smith.withdraw(sDraw);
			
			System.out.println("Enter The amount to be Withdrawn: ");
			double kDraw=scan.nextDouble();
			kathy.withdraw(kDraw);
		scan.close();
		}

}

