enum Gender
{
	M,F,m,f;
}

public class Person25 {
		String firstName;
		String lastName;
		long phone;
		Gender gender;
		
		public Person25() {
			super();
		}
		
		
		public Person25(String firstName, String lastName, long phone,
				Gender gender) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.phone = phone;
			this.gender = gender;
		}

		
		public String getFirstName() {
			return firstName;
		}


		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}


		public String getLastName() {
			return lastName;
		}


		public void setLastName(String lastName) {
			this.lastName = lastName;
		}


		public long getPhone() {
			return phone;
		}


		public void setPhone(int phone) {
			this.phone = phone;
		}


		public Gender getGender() {
			return gender;
		}


		public void setGender(Gender gender) {
			this.gender = gender;
		}


		public String dispPerDetails()
		{
			return "\nFirst Name: "+firstName+"\nLast Name: "+lastName+"\nPhone No.:"+phone+"\nGender: "+gender;
		}

}

