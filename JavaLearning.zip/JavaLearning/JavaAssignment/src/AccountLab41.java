
public class AccountLab41 extends PersonLab41 {
	
	long accNum;
	double accBal;
	PersonLab41 accHolder;
	public AccountLab41() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AccountLab41(String name, float age) {
		super(name, age);
		// TODO Auto-generated constructor stub
	}
	public AccountLab41(long accNum, double accBal, String name, float age) {
		super(name, age);
		this.accNum = accNum;
		this.accBal = accBal;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public PersonLab41 getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(PersonLab41 accHolder) {
		this.accHolder = accHolder;
	}
	public void setBalance(double balance) {
		this.accBal = balance;
	}
	public double getBalance(){
		return accBal;
	}
	public void deposit(double amt)
	{
		accBal=amt+accBal;
		System.out.println(tostring()); 
	}
	public void withdraw(double amt)
	{
		accBal=accBal-amt;
		if(accBal>=500)
		{
		System.out.println(tostring());
		}
		else
		{
			System.out.println("Insufficient Balance");
		}
	}
	public String tostring(){
		return ("\nAccount Number: "+(long)Math.floor(Math.random()*9_000_000_000L)+"\nAccount Holder: "+name+"\nAge:"+age+"\nBalance: "+accBal);
	}
}

	
