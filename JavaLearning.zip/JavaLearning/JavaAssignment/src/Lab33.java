import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Lab33 {
	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a Day: ");
		int day = scan.nextInt();
		System.out.println("Enter a Month: ");
		int mon = scan.nextInt();
		System.out.println("Enter a Year: ");
		int yr = scan.nextInt();
		LocalDate date = LocalDate.of(yr, mon, day);
		Period per = Period.between(date, today);
		System.out.println("The difference is :" + per.getYears() + "-Years "
				+ per.getMonths() + "-Months " + per.getDays() + "-Days ");
		scan.close();
	}
}
