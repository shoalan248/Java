import java.time.LocalDate;
import java.time.Period;

public class LabClass37 {
		String firstName;
		String lastName;
		char gender;
		LocalDate dob;
		
				
		public LabClass37() {
			super();
		}

		
		public LabClass37(String firstName, String lastName, char gender,
				LocalDate dob) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.gender = gender;
			this.dob = dob;
		}
		
		
		public String getFirstName() {
			return firstName;
		}


		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}


		public String getLastName() {
			return lastName;
		}


		public void setLastName(String lastName) {
			this.lastName = lastName;
		}


		public char getGender() {
			return gender;
		}


		public void setGender(char gender) {
			this.gender = gender;
		}


		public LocalDate getDob() {
			return dob;
		}


		public void setDob(LocalDate dob) {
			this.dob = dob;
		}


		public String calcAge(LocalDate dob){
			LocalDate curDate=LocalDate.now();
			Period perDob=Period.between(curDate, dob);
			return (perDob.getYears()+"Years"+perDob.getMonths()+"Months"+perDob.getDays()+"Days");
		}
		
		public String mergeName(){
			return ("Full Name: "+firstName+" "+lastName);
		}
		
		public String dispPerDetails()
		{
			return "Gender: "+gender;
		}
		
}