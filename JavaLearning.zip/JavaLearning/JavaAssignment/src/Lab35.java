import java.time.LocalDate;
import java.util.Scanner;

public class Lab35 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Purchase Date's day: ");
		int pDay=scan.nextInt();
		System.out.println("Enter the Purchase Date's month: ");
		int pMon=scan.nextInt();
		System.out.println("Enter the Purchase Date's year: ");
		int pYr=scan.nextInt();
		
		LocalDate pDate=LocalDate.of(pYr, pMon, pDay);
		
		System.out.println("Enter the Warranty Date's year: ");
		int wYear=scan.nextInt();
		System.out.println("Enter the Warranty Date's month: ");
		int wMon=scan.nextInt();
		
		int expMon=(wYear*12)+wMon;
		System.out.println("The Product expires on: "+pDate.plusMonths(expMon));	
		scan.close();
	}

}
