import java.util.Scanner;
import java.util.TimeZone;

public class Lab36 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Time Zone ID: ");
		String zoneID=scan.next();
		
		TimeZone timeZone = TimeZone.getTimeZone(zoneID);
		System.out.println("The current Time Zone is: "+timeZone);
scan.close();
}
}
