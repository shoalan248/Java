public class CurrentAccLab42 extends AccountParentLab42 {
	
	public int overDraftLimit=10000;
	
	
	
	
	public CurrentAccLab42() {
		super();
		// TODO Auto-generated constructor stub
	}




	public CurrentAccLab42(String accHolder, long accNum, double balance) {
		super(accHolder, accNum, balance);
		// TODO Auto-generated constructor stub
	}

	



	public CurrentAccLab42(int overDraftLimit) {
		super();
		this.overDraftLimit = overDraftLimit;
	}



	@Override
	public void withdraw(double amt)
	{
		if((balance<amt)&&(amt-balance)<10000)
		{
		System.out.println(tostring());
		}
		else
		{
			System.out.println("Over Draft Limit is crossed.");
		}
	}


}
