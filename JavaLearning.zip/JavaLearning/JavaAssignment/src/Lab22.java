public class Lab22 {
	int num;

	public int Number(int number) {
		num = number;
		if (num > 0) {
			System.out.println("The number " + num + " is a positive number");
		} else {
			System.out.println("The number " + num + " is a negative number");
		}
		return num;
	}

	public static void main(String args[]) {

		int num = Integer.parseInt(args[0]);
		Lab22 obj = new Lab22();
		System.out.println(+obj.Number(num));

	}

}
