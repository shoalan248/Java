
public class Lab24 {
	String FirstName;
	String LastName;
	long Phone;
	char Gender;
	public Lab24() {
		super();
		
	}
	public Lab24(String firstName, String lastName, long phone, char gender) {
		super();
		FirstName = firstName;
		LastName = lastName;
		Phone = phone;
		Gender = gender;
	}
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public long getPhone() {
		return Phone;
	}
	public void setPhone(long phone) {
		Phone = phone;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public String dispPerDetails()
	{
		return "\nFirst Name: "+FirstName+"\nLast Name: "+LastName+"\nPhone: "+Phone+"\nGender: "+Gender;
	}
	

}
