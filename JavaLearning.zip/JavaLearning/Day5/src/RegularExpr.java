import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpr {

	public static void main(String[] args) {
		String ipStr="Koi ek string de de";
		String pattern="Koi ek string de de";

		boolean patternMatched= Pattern.matches(ipStr, pattern);
		System.out.println("Pattern is matched: "+patternMatched);
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter ur name: ");
		String frstName=scan.next();
		String namePattern="[A-Z][a-z]+";
		
		if(Pattern.matches(namePattern, frstName))
		{
			System.out.println("Hey "+frstName+"!!");
		}
		else
		{
			System.out.println("The name's first letter needs to be in uppercase and should contain only characters.");
		}
		
		
		String input="Shop,Hopping,Mop,Chopping";
		Pattern pattern1=Pattern.compile("hop");
		Matcher match=pattern1.matcher(input);
		System.out.println(""+match.matches());
		while(match.find())
		{
			System.out.println(match.group()+":"+match.start()+":"+match.end());
		}
		
		scan.close();
	}

}
