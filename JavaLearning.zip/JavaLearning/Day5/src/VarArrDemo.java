class Calculator
{
	public void add(/* String name, */int ... nums)
	{
		int sum=0;
		for(int temp:nums)
		{
			sum=sum+temp;
		}
		System.out.println(/* name+ */"The sum is "+sum);
	}
}
public class VarArrDemo {

	public static void main(String[] args) {
		Calculator calc=new Calculator();
		calc.add(/* "shuhbam" */ 10,20,30,40,50,60);
		

	}

}
