import static java.lang.Math.PI;
public class EnhancedForLoop {

	public static void main(String[] args) {
		int marks[]=new int[4];
		marks[0]=99;
		marks[1]=92;
		marks[2]=96;
		marks[3]=89;
		
		for(int temp:marks)
		{
			System.out.println(temp);
		}
		System.out.println("________Cities________");
		String []cities={"Chennai","Rajasthan"};
		for(String temp:cities)
		{
			System.out.println(temp);
		}
		System.out.println("pi="+PI);//Usually for accessing values of static classes we should use clasName.fn(Math.PI) that's y I imported that class
	}

}
