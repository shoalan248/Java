public class StudentDemo 
{
	public static void main(String args[])
	{
		Student s1=new Student();
		s1.setRollNo(1001);
		s1.setStudName("Alankrita");
		s1.setMarks(100);
		
		Student s2=new Student();
		s2.setRollNo(1002);
		s2.setStudName("Krita");
		s2.setMarks(99);
		
		System.out.println("Roll No: "+s1.getRollNo()+
				"\nStudent Name: "+s1.getStudName()+
				"\nStudent Marks: "+s1.getMarks());
		System.out.println("Roll No: "+s2.getRollNo()+
				"\nStudent Name: "+s2.getStudName()+
				"\nStudent Marks: "+s2.getMarks());
		
	}
	
}
