package snippet;

public class Snippet {
	public static void main(String[] args) {
		System.out.println(" USERNAME = "+user);
	}
}

