
public class Employee {
	int empId;
	String empName;
	float empSal;
	char gender;

	public Employee()
	{
		empId=0;
		empName=null;
		empSal=0;
		gender='\0';
	}
	public Employee(int empId,String empName,float empSal,char gender)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
		this.gender=gender;
	}
	public String dispDetails()
	{
		return "\nEmployee ID: "+empId+"\nEmployee Name: "+empName+"\nEmployee Sal:"+empSal+"\nGender: "+gender;
	}
	

}
