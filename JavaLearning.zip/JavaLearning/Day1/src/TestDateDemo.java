public class TestDateDemo 
{
	public static void main(String[] args)
	{
		varDate shubh=null;
		shubh=new varDate();
		
		shubh.setDate(25,10,2017); //Wo comment block me hai isliye jyada tension mat le
		System.out.println("My DOJ is: "+shubh.dispDate());
	}
}
//Both ways of initialization are correct and this obj is a reference variable of type date




/*

public class TestDateDemo 
{
	public static void main(String[] args)
	{
		varDate shubh=new varDate();
		
		shubh.setDate(25,10,2017);
		System.out.println("My DOJ is: "+shubh.dispDate());
	}
}*/