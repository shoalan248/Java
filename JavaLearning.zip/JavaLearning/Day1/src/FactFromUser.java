class Fact {
	int num;

	public int calcFact(int number) {
		num = number;
		int fact = 1;
		while (num > 1) {
			fact = fact * num--;

		}
		return fact;
	}
}

public class FactFromUser {
	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		FactFromUser obj = new FactFromUser();
		System.out.println("Factorial is" + obj.calcFact(num));
	}

}
