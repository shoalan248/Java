public class Array {

	public static void main(String[] args) {
		int marks[] = new int[4];
		marks[0] = 98;
		marks[1] = 90;
		marks[2] = 95;
		marks[3] = 92;

		for (int i = 0; i < marks.length; i++) {
			System.out.println("marks[" + i + "]:" + marks[i]);
		}

		// Another way of declaring and initializing an array

		String[] cityList = { "Pune", "Mumbai", "bangalore", "Chandigarh" };
		for (int i = 0; i < cityList.length; i++) {
			System.out.println("cityList[" + i + "]:" + cityList[i]);
		}

		// Another way of declaring and initializing an array

		int a[][] = new int[3][2];
		a[0][0] = 9;
		a[0][1] = 3;
		a[1][0] = 5;
		a[1][1] = 6;
		a[2][0] = 7;
		a[2][1] = 8;
		for (int j = 0; j < a.length; j++) {
			for (int k = 0; k < a[j].length; k++) {
				System.out.println("" + a[j][k]);
			}
			System.out.println();
		}

	}
}
