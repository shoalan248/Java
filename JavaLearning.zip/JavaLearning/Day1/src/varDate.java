// Related to person.java and varDate.java
/*
public class varDate 
{
	int day;
	int mon;
	int year;
	public void initDate()
	{
		day=0;
		mon=0;
		year=0;
	}
	public void setDate(int dd,int mm,int yy)
	{
		day=dd;
		mon=mm;
		year=yy;
	}
	public String dispDate()
	{
		return day+"-"+mon+"-"+year;
	}
}

*/

 
public class varDate 
{
	int day;
	int mon;
	int year;
	public varDate()
	{
		day=0;
		mon=0;
		year=0;
	}
	public varDate(int day,int mon,int year)
	{
//		this(); //calling constructor from a constructor
		this.day=day;
		this.mon=mon;
		this.year=year;
//this.dispDate(); //calling function but is same as dispDate();
	}
	public String dispDate()
	{
		return " "+day+"-"+mon+"-"+year;
	}
}

