public class em {

	public static void main(String[] args) {

		Employee emp = new Employee(1001, "Alankrita", 60000, 'F');
		System.out.println(emp.dispDetails());

	}

}
