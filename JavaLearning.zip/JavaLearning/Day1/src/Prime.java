class Primes {
	int num;
	int flag = 0;
	int i;

	public int calcPrimes(int number) {
		num = number;
		for (i = 1; i <= 9; i++) {
			if (num % i != 0) {
				flag = flag + 1;
			} else {
				flag = flag + 10;

			}
			return flag;
		}
		return number;
	}
}

public class Prime {
	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		Prime obj1 = new Prime();
		System.out.println("Prime is" + obj1.calcPrimes(num));
	}

}
