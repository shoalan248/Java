public class PrintableCustomer {
	public static void main(String args[]){
		/*Printable pArr[]=new Printable[2];
		pArr[0]=new Customer(1001,"Shubh");
		pArr[1]=new Customer(1002,"Shubham");
		pArr[0].print();//Ye aur iske neeche wala fn. dono customer aur printable me hai isliye we can use.
		pArr[1].print();
		*/
		Printable p1=new Customer(222,"Shubham");
		p1.print();
		System.out.println(((Customer)p1).sayHi());  //I'm TypeCasting it as this fn. is not in the interface(parent). So for showing the compiler that the fn. is in the hild class im using this.
	}
}
