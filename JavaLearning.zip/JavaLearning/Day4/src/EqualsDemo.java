public class EqualsDemo {
	public static void main(String args[])
	{
		Integer i1=new Integer(10);
		Integer i2=new Integer(20);
		Integer i3=new Integer(30);
		
		if(i1.equals(i3))
		{
		System.out.println("They are Equal:");
		System.out.println("Hash code of i1 is: "+i1.hashCode());
		System.out.println("Hash code of i2 is: "+i2.hashCode());
		System.out.println("Hash code of i3 is: "+i3.hashCode());
		}
		else
		{
		System.out.println("They are Not Equal:");
		System.out.println("Hash code of i1 is: "+i1.hashCode());
		System.out.println("Hash code of i2 is: "+i2.hashCode());
		System.out.println("Hash code of i3 is: "+i3.hashCode());
		}
		System.out.println("             String Comparison              ");
		String s1="Shubham";
		String s2=new String("Vaya");
		String s3="Shubham";
		String s4=new String("Shubham");
		StringBuffer city=new StringBuffer("Chennai");
		
		System.out.println("Hash code of s1 is: "+s1.hashCode());//Displays same hashCode as in s3 because both have same values 
		System.out.println("Hash code of s2 is: "+s2.hashCode());
		System.out.println("Hash code of s3 is: "+s3.hashCode());
		System.out.println("Hash code of s4 is: "+s4.hashCode());
		System.out.println("Hash code of city is: "+city.hashCode());
		
		System.out.println("Is s1 == s2? "+(s1 == s2));
		System.out.println("Is s1 == s3? "+(s1 == s3));
		System.out.println("Is s1 == s4? "+(s1 == s4));
		
		System.out.println("Is s1 Equals s2? "+(s1.equals(s2)));
		System.out.println("Is s1 Equals s3? "+(s1.equals(s3)));
		System.out.println("Is s1 Equals s4? "+(s1.equals(s4)));
		/* Yaha par The string var me jo declare kiya aur jo string obj me declare kiya, in dono == check nahi kar sakta hai but equals() can check
		*/
	}

}
