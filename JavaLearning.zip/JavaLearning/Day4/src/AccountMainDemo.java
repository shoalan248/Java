import java.util.Scanner;

public class AccountMainDemo {

	public static void main(String[] args) 
	{
		
		int curBal=50000;
		try(Scanner scan=new Scanner(System.in)) //ye use kare to line 32 wala ca5tch bhi use karna.. This is done to automatically close scanner
		{
		System.out.println("Enter the withdrawl amount: ");
		int withDrawAmt=scan.nextInt();
		
		if(withDrawAmt>=curBal)
		{ 
			try
			{
			throw new LowBalanceException("Insufficient Balance");
		}
			catch (LowBalanceException lbe)
			{
				System.out.println(lbe);
				//System.out.println("Enter amt lower than ur bal");
			}
		}
			else
			{
				System.out.println("Balance is"+(curBal-withDrawAmt));
			}

	}
		catch(Exception e)
		{ 
			e.printStackTrace();
		}
}
}