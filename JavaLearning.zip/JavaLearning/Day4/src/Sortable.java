public interface Sortable {
	Sortable Sort(Sortable list[]);

}
