public class TestWrapperDemo {
	public static void main(String args[]){
		int i=0;
		Integer i1=new Integer(i);//Pre java5 command
		
		int k=i1.intValue();//Pre java5 command
		
		Integer i2=10;//AutoBoxing..   post java5 command
		
		int z=i1;//AutoUnBoxing..    post java5 command
	}
	
}
