import java.io.IOException;

public class ThrowDemo {
	public static void main(String args[])
	{
		ExceptionThrows et=new ExceptionThrows();
		try{
		et.method1();
		
	} catch (IOException ioe)
	{
		ioe.printStackTrace();
	}
}
}
// agar ExceptionThrows.java se comment wala code use karega to is prg se line no.7,9,10,11,12 sab nikal de
