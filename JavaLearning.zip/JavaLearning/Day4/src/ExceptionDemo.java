import java.util.Scanner;

class Calculator{
	int num1;
	int num2;
	
	public Calculator()
	{}
	
	public Calculator(int num1,int num2)
	{
		this.num1=num1;
		this.num2=num2;
	}
	public float divide()
	{
		float result=0.0f;
	try{
		
		result=num1/num2;
		}
/*	catch(ArithmeticException ae)
	{
		System.out.println("The number should not be zero");
	}
	catch(ArrayIndexOutOfBoundsException ase)
	{
		System.out.println("The array size needs to be chacked ");
	}
	catch(Exception e)
	{
		System.out.println("Other Exceptions");
		e.printStackTrace();
	}
*/
	catch(ArrayIndexOutOfBoundsException|ArithmeticException ae)
	{
		System.out.println("ye le watt lagi teri");
		ae.printStackTrace();
	}
	finally
	{
		System.out.println("This block in finally always gets executed irrespective of the exceptions");
	}
	return result;
	}
}


public class ExceptionDemo {

	public static void main(String args[]){
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter numbers :");
		int num1=scan.nextInt();
		int num2=scan.nextInt();
		Calculator cal=new Calculator(num1,num2);
		System.out.println("Division of numbers is: "+cal.divide());
		scan.close();
	}

}
