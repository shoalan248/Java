import java.awt.print.Printable;

public abstract class Customer implements Printable//,Sortable
{
	private int custId;
	private String custName;
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Customer(int custId, String custName) {
		super();
		this.custId = custId;
		this.custName = custName;
	}
	public void print(){
		System.out.println("Customer Id: "+custId);
		System.out.println("Customer Id: "+custName);
	}
	
	public String sayHi(){
		return "welcome Shubham";
	}
	
/*	public Sortable sort(Sortable[] list)
	{
		return null;
	}
	*/
}
