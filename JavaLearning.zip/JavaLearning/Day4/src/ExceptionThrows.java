/* import java.io.IOException;

public class ExceptionThrows {
	
	public void method1()
	{
		System.out.println("Method1 is the current method");
		method2();		
	}
	public void method2()
	{
		System.out.println("Method2 is the current method");
		try{
			throw new IOException();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
}
*/

import java.io.IOException;

public class ExceptionThrows {
	
	public void method1()throws IOException
	{
		System.out.println("Method1 is the current method");
		method2();		
	}
	public void method2()throws IOException
	{
		System.out.println("Method2 is the current method");

			throw new IOException();
	}
}


