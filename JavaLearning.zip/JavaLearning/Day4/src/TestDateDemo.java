import java.time.Period;
import java.time.LocalDate;
//import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TestDateDemo {
	public static void main(String args[]){
		
		LocalDate today=LocalDate.now();
		System.out.println("Today is "+today);
		
		System.out.println("Today is "+today.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")));
		
		/*LocalDateTime hey=LocalDateTime.now();
		System.out.println("Today is "+hey);*/
	
		System.out.println("To print date in some format");
		LocalDate dobDate=LocalDate.of(1996, 06, 22);
		System.out.println("format will be : "+dobDate);
		
		System.out.println("After 2 days : "+today.plusDays(2));
		
		Period per=Period.between(dobDate, today);
		
		System.out.println("Aaj tak ki: "+per.getYears()+"Years"+per.getMonths()+"Months"+per.getDays()+"Days");
	
	String bDate="22-Jun-1996";
	
	DateTimeFormatter myFormatter=DateTimeFormatter.ofPattern("dd-mm-yyyy");
	
	LocalDate myDob=LocalDate.parse(bDate,myFormatter);
	System.out.println("My DOB:"+myDob.format(myFormatter));
	}
	
}
