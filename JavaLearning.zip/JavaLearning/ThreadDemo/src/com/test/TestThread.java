package com.test;

public class TestThread {
	
	public static void main(String[] args) throws Exception
	{
		FirstThread first=new FirstThread();
		SecondThread second=new SecondThread();
		
		Thread t1=new Thread(first);
		Thread t2=new Thread(second);
		t1.start();
		t2.start();
		//first.join();
		//second.join();		
		System.out.println(" MAIN COMPLETED"+Thread.currentThread());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}

}
