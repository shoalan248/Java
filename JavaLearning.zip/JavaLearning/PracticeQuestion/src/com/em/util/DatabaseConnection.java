package com.em.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.em.exception.EmpException;

public class DatabaseConnection {
	

	public static Connection getConnection() throws EmpException
	{
		Connection con=null;
		Properties props=new Properties();
		
		try {
			FileReader fRead=new FileReader("resource/jdbc.properties");
			props.load(fRead);
			String url=props.getProperty("jdbcurl");
			String user=props.getProperty("jdbcuser");
			String pass=props.getProperty("jdbcpass");
			con=DriverManager.getConnection(url, user, pass);
		} catch (FileNotFoundException e) {
			throw new EmpException("jdbc.properties File not Found");
			
		} catch (IOException e) {
			throw new EmpException("Unable to read jdbc.properties file");
			
		} catch (SQLException e) {
			throw new EmpException("Connection failed");
			
		}
		return(con);
	}

}
