package com.em.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.em.bean.EmpBean;
import com.em.exception.EmpException;
import com.em.util.DatabaseConnection;
import com.em.dao.EmployeeDAOImplement;

public class EmployeeDAOImplement implements EmpDAO {
	
	Logger log=Logger.getLogger(EmployeeDAOImplement.class);

	public EmployeeDAOImplement() {
		super();
		PropertyConfigurator.configure("resource/log4j.properties");
	}
	public int generateEmployeeID() {
		int id = 0;
		Connection con = null;
		String qry = "select Empid_sequence.nextval from dual";
		try {
			con = DatabaseConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id = rst.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addEmployee(EmpBean bean) throws EmpException {
		Connection con = null;
		String cmd = "insert into Employee_tbl(Emp_id,Emp_firstName,Emp_LastName,Emp_ContactNumber,Emp_DOJ,Emp_Email) values(?,?,?,?,SYSDATE,?)";
		int id = 0;
		PreparedStatement pstmt;
		log.debug("Add Employee is called from EmpDao");
		log.info("Add Employee Called");
		try {
			con = DatabaseConnection.getConnection();
			id = generateEmployeeID();
			pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmp_firstName());
			pstmt.setString(3, bean.getEmp_lastName());
			pstmt.setLong(4, bean.getEmp_ContactNumber());
			pstmt.setString(5, bean.getEmp_Email());

			pstmt.executeUpdate();
			log.info("Insert Successful");
			
		} catch (SQLException e) {
			log.debug("Insertion Failed"+e);
			throw new EmpException("Unable to insert");
		}

		return id;
	}

	public String viewById(int id) throws EmpException {
		Connection con = null;
		EmpBean bean = new EmpBean();
		String cmd = "select Emp_id,Emp_firstName,Emp_LastName,Emp_ContactNumber,Emp_DOJ,Emp_Email from Employee_tbl where empid="
				+ id;

		try {

			con = DatabaseConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(cmd);
			System.out.println("Employee Details are: ");
			rst.next();
			bean.setEmp_id(rst.getInt(1));
			bean.setEmp_firstName(rst.getString(2));
			bean.setEmp_lastName(rst.getString(3));
			bean.setEmp_ContactNumber(rst.getInt(4));
			bean.setEmp_DOJ(rst.getDate(5));
			bean.setEmp_Email(rst.getString(6));

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return (bean.getEmp_id() + " " + bean.getEmp_firstName() + " "
				+ bean.getEmp_lastName() + " " + bean.getEmp_ContactNumber()
				+ " " + bean.getEmp_DOJ() + " " + bean.getEmp_Email());
	}

	
}
