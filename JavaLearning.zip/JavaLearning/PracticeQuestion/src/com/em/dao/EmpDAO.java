package com.em.dao;

import com.em.bean.EmpBean;
import com.em.exception.EmpException;

public interface EmpDAO {

	public int addEmployee(EmpBean bean) throws EmpException;
	public String viewById(int id) throws EmpException;
	 
	
}
