package com.em.pl;

import java.util.Scanner;

import com.em.bean.EmpBean;
import com.em.exception.EmpException;
import com.em.service.EmpServiceImplement;

public class EmpMain {
	
	static EmpServiceImplement empServiceImpl = null;
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);

		EmpBean bean = new EmpBean();
		EmpServiceImplement service = new EmpServiceImplement();

		System.out
				.println("Select your operation: \n1.Add Employee\n2.View Employee by Id \n3.Exit");
		int choice = scan.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter employee's First name");
			String efirstname = scan.next();
			System.out.println("Enter employee's Last name");
			String elastname = scan.next();
			System.out.println("Enter employee's contact number");
			int econtact = scan.nextInt();
			System.out.println("Enter employee's email ID");
			String eemail = scan.next();
			bean.setEmp_firstName(efirstname);
			bean.setEmp_lastName(elastname);
			bean.setEmp_ContactNumber(econtact);
			bean.setEmp_Email(eemail);
			
			empServiceImpl = new EmpServiceImplement();
			try {
			 if(empServiceImpl.validateEmployee(bean))
			 {
				 System.out.println("Added Success");
			 }
			} catch (EmpException e) {
				e.printStackTrace();
				System.err.println("Invalid Data");
				System.exit(0);
			}
			try {
				int id = service.addEmployee(bean);
				System.out.println("Employee Added Successfully");
				System.out.println("Employee ID: " + id);
			} catch (EmpException e) {
				System.out.println(e);
			}
			break;

		case 2:
			try {
				System.out.println("Enter the Employee's ID:");
				int id = scan.nextInt();
				System.out.println(service.viewById(id));
			} catch (EmpException e) {
				e.printStackTrace();
			}
			break;

		case 3:
			break;
		}
		scan.close();

	}
}
