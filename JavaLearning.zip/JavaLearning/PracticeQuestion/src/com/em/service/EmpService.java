package com.em.service;

import com.em.bean.EmpBean;
import com.em.exception.EmpException;



public interface EmpService {
	int addEmployee(EmpBean bean)throws EmpException;
	String viewById(int id) throws EmpException;
	

}
