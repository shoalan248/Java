package com.em.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.em.bean.EmpBean;
import com.em.dao.EmpDAO;
import com.em.dao.EmployeeDAOImplement;
import com.em.exception.EmpException;

public class EmpServiceImplement implements EmpService {

	EmpDAO empdao = new EmployeeDAOImplement();


	@Override
	public int addEmployee(EmpBean bean) throws EmpException {
		int id = empdao.addEmployee(bean);
		return id;
	}


	public String viewById(int id) throws EmpException {
		String bean = empdao.viewById(id);
		return bean;
	}

	
	public boolean validateEmployee(EmpBean bean) throws EmpException {
		boolean validate = true;
		List<String> validationErrors = new ArrayList<String>();

		// Validating Employee First Name
		if (!(isValidfirstName(bean.getEmp_firstName()))) {
			validationErrors
					.add("\n First Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		// Validating Employee Last Name
		if (!(isValidlastName(bean.getEmp_lastName()))) {
			validationErrors
					.add("\n Last Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		// Validating Employee Contact Number
		if (!(isValidPhoneNumber(bean.getEmp_ContactNumber()))) {
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		// Validating address
		if (!(isValidEmail(bean.getEmp_Email()))) {
			validationErrors.add("\n Email ID Should Be valid \n");
		}

		if (!validationErrors.isEmpty()) {
			throw new EmpException(validationErrors +"");
	}
	else{
		validate=false;
	}
	return validate;
}

	public boolean isValidfirstName (String Emp_firstName) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(Emp_firstName);
		return nameMatcher.matches();
	}

	public boolean isValidlastName(String Emp_lastName) {
		Pattern namePattern = Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher = namePattern.matcher(Emp_lastName);
		return nameMatcher.matches();
	}

	public boolean isValidPhoneNumber(long Emp_ContactNumber) {
		Pattern phonePattern = Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher = phonePattern.matcher(String.valueOf(1));
		return phoneMatcher.matches();

	}

	public boolean isValidEmail(String Emp_Email) {
		Pattern EmailPattern = Pattern
				.compile("^([A-Za-z0-9])+@([A-Za-z0-9])+([A-Za-z]{3,6})$/");
		Matcher EmailMatcher = EmailPattern.matcher(Emp_Email);
		return EmailMatcher.matches();
	}

	
}
