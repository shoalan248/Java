package com.em.dao.test;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.Test;

import com.em.exception.EmpException;
import com.em.util.DatabaseConnection;

public class TestDBConnection {

	@Test
	public void TestConnection() throws EmpException {
		Connection con = DatabaseConnection.getConnection();
		assertNotNull(con);
	}
	@Test(expected = EmpException.class)
	public void TestConnectionFail() throws EmpException {
		Connection con = DatabaseConnection.getConnection();
	}

}
