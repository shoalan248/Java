package com.em.dao.test;

import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import com.em.bean.EmpBean;
import com.em.dao.EmployeeDAOImplement;
import com.em.exception.EmpException;

public class TestDAO {

	static EmployeeDAOImplement empdao;
	static EmpBean empBean;

	@BeforeClass
	public static void beforeClass() {
		empdao = new EmployeeDAOImplement();
		empBean = new EmpBean();
	}

	@Test
	public void testAddEmp() throws EmpException {
		empBean.setEmp_firstName("Alankrita");
		empBean.setEmp_lastName("Singh");
		empBean.setEmp_ContactNumber(916);
		empBean.setEmp_Email("alan@gmail.com");
		int id = empdao.addEmployee(empBean);
		assertTrue(id > 0);
	}

}
