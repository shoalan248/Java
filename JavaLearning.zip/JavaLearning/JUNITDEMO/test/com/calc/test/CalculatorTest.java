package com.calc.test;

import static org.junit.Assert.*; //import static method bcoz assert has all static methods

import org.junit.BeforeClass;
import org.junit.Test;

import com.calc.Calculator;

public class CalculatorTest {
	
	static Calculator obj;
	@BeforeClass
	public static void beforeTest()
	{
		Calculator obj=new Calculator();
	}
	@Test
	public void testAdd()
	{
		
		int n=obj.add(10, 20);
		assertEquals(30,n);
	}
	
	@Test
	public void testSub()
	{
		int n=obj.sub(10,5);
		assertEquals("testing 10 and 5",5,n);
	}
	
	@Test
	public void testDivide()
	{
		int n=obj.divide(20,2);
		assertEquals(10,n);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testDivideException()
	{
		int n=obj.divide(20,0);
	}


}
//u cant refer the local reference in another object, so declare as a field in class
//add beforeclass and afterclass should have static object
