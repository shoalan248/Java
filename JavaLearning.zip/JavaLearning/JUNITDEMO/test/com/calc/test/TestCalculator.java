package com.calc.test;



import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestCalculator {

	@BeforeClass
	public static void beforeClass() // method
	{
		System.out.println(" before class called");
	}

	@AfterClass
	public static void afterClass() {
		System.out.println(" after class called");
	}

	@Before
	public void beforeTest() {
		System.out.println(" Before test called");
	}

	@After
	public void afterTest() {
		System.out.println(" After test called");
	}

	@Ignore
	@Test
	public void m1() {
		System.out.println(" m1 called");
	}

	@Test
	public void m2() {
		System.out.println(" m2 called");
	}

}
