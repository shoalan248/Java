import com.cg.uas.bat.Batch;
import com.cg.uas.stu.Student;

public class StudentBatch {
	public static void main(String args[]) {
		Batch javaBatch=new Batch("JEE_ABRG_FS","8.30AM To 7.30A.M","Shubh");
		Batch autoTestBatch=new Batch("AUTO_VNV_FS_PT","9.30AM To 8.30A.M","Vaya");
		Student Shubham=new Student(12345,"Shubham",javaBatch);
		Student Shub=new Student(67890,"Shub",autoTestBatch);
		
		System.out.println(""+Shubham.dispStuInfo());
		System.out.println(""+Shub.dispStuInfo());
	}

}
