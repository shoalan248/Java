/*
public class Emp 
{
	private int empId;
	private String empName;
	private float empSal;
	public Emp()
	{}
	public Emp(int empId,String empName,float empSal)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
	}
	public String dispEmpInfo()
	{
		return "Emp [empId=" +empId+", empName=" +empName+", Basic empSal=" +empSal+ "]";
	}
	public float calEmpAnnualSal()
	{
		return empSal*12;
	}

}
*/

public class Emp 
{
/*
	static{

		System.out.println("Static blocks are invoked when the classes are loaded at memory by class loader");
		System.out.println("Static blocks are invoked before the main fn so if it is placed within the void main it won't be excuted");
	}
*/
	private int empId;
	private String empName;
	private float empSal;
	private static int count; //Static var are similar to global var and are stored in a static mem section
	
	public Emp()
	{}
	public Emp(int empId,String empName,float empSal)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
		count++;
	}
	public String dispEmpInfo()
	{
		return "Emp [empId=" +empId+", empName=" +empName+", Basic empSal=" +empSal+ "]";
	}
	public float calEmpAnnualSal()
	{
		return empSal*12;
	}
	
	public static void getCount()
	{
		System.out.println("Emp count is: "+count);
	}
}
