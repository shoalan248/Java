// Related to person.java and varDate.java
import java.util.Scanner;

public class DobDemo 
{
	public static void main(String args[])
	{
		Scanner p1=new Scanner(System.in);
/*
		System.out.println("Enter the no of employees: ");
		int noOfPer=p1.nextInt();
		Person pers[]=new Person[noOfPer];
		
		for(int i=0;i<noOfPer;i++)
		{ 
		
		System.out.println("Enter the Pan no: ");
		String pan=p1.next();
		System.out.println("Enter the Person's Name: ");
		String nam=p1.next();
		System.out.println("Enter the Person's Sal: ");
		float sal=p1.nextFloat();
		System.out.println("Enter the Person's Day: ");
		int day=p1.nextInt();
		System.out.println("Enter the Person's Mon: ");
		int mon=p1.nextInt();
		System.out.println("Enter the Person's Year: ");
		int yr=p1.nextInt();
		
		varDate dob = new varDate(day , mon,yr);
		pers[i] =new Person(pan , nam ,sal , dob);
		}
		
		for(int i=0;i<noOfPer;i++)
		{		
			System.out.println(i +"th Employee info"+pers[i].dispPersonalInfo());
		}
*/
		varDate sDOB=new varDate();
		varDate dDOB=new varDate();
		varDate vDOB=new varDate();
/*		
		String ge=new Scanner(System.in).next();
		Gender gen=Gender.valueOf(ge);
*/		
		//Next line me neeche dekh gender ke waha pe obj "gen" use kiya hai if the above 2 lines are used to get details from user at runtime
		Person shubh=new Person("ABCDE4563F","Shubh",50000.0f,/*gen*/Gender.M,sDOB);
		Person vaya=new Person("GHIJK4563L","Vaya",45000.0f,Gender.M,vDOB);
		Person sahil=new Person("GHIJK4563L","Sahil",46000.0f,Gender.M,dDOB);
		
		System.out.println(" "+shubh.dispPersonalInfo());
		System.out.println(" "+vaya.dispPersonalInfo());
		System.out.println(" "+sahil.dispPersonalInfo());

		//System.out.println("Pan="+pan+"\nname="+nam+"\nsalary="+sal+"\ndob="+day+"-"+mon+"-"+yr);
p1.close();
	}

}
