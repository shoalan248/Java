class CalcDemo
{
	public void add(int num1, int num2)
	{
		System.out.println("Addition of 2 integers:" +(num1+num2));
	}
	public void add(int num1, int num2,int num3)
	{
		System.out.println("Addition of 3 integers:" +(num1+num2+num3));
	}
	public void add(byte num1, byte num2)
	{
		System.out.println("Addition of 2 bytes:" +(num1+num2));
	}
	public void add(float num1, float num2)
	{
		System.out.println("Addition of 2 floats:" +(num1+num2));
	}
	public void add(double num1, double num2)
	{
		System.out.println("Addition of 2 double:" +(num1+num2));
	}
	public void add(String num1, String num2)
	{
		System.out.println("Addition of 2 Strings:" +(num1+" "+num2));
	}
	public void add(Integer num1, Integer num2)
	{
		System.out.println("Addition of two Int wrappers:" +(num1+num2));
	}
}

public class Calc
{
	public static void main(String args[])
	{
		CalcDemo c1=new CalcDemo();
		c1.add(10,20);
		c1.add(10,20,30);
		c1.add(10.0,20.0);// This will call double as we did not use .0f there
		c1.add(10.0f,20.0f);
		c1.add("Shubh","Vaya");
		c1.add((byte)10,(byte)20);
		c1.add(new Integer(10),new Integer(20));
		c1.add((Integer)10,(Integer)20);
	}
}