import java.util.Scanner;

public class EmpDemo 
{
/*
	private static String city="pune"; //This var and the next method can be called only by the class name.var and method that too with the type being static
	public static void method1(){
		System.out.println("hey");
	}
*/
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the No. of employees: ");
		int n=sc.nextInt();
		Emp emps[]=new Emp[n];

/*
		emps[0]=new Emp(1001,"Shubh",100000.0f);
		emps[1]=new Emp(1002,"Shubham",70000.0f);
		emps[2]=new Emp(1003,"Vaya",80000.0f);
*/
		for(int i=0;i<n;i++)
		{
/*
			System.out.println(i +"th Employee info"+emps[i].dispEmpInfo());
			System.out.println(i +"th Employee info"+emps[i].calEmpAnnualSal());
*/
			System.out.print("Enter the Emp ID: ");
			int eid=sc.nextInt();
			
			System.out.print("Enter the Emp Name: ");
			String ename=sc.next();
			
			System.out.print("Enter the Emp Salary: ");
			float esal=sc.nextFloat();
			System.out.print("\n");
			emps[i]=new Emp(eid,ename,esal);
		}
		for(int i=0;i<n;i++)
		{
			System.out.println(i +"th Employee info"+emps[i].dispEmpInfo());
			System.out.println(i +"th Employee sal"+emps[i].calEmpAnnualSal());
		}
		Emp.getCount();
/*		
		EmpDemo.method1();
		System.out.println("city is"+EmpDemo.city); //If the var is in the same class then no need to give the class name
*/
		sc.close();
	}

}
