public class varDate {
		int day;
		int mon;
		int year;
		public void initDate()
		{
			day=0;
			mon=0;
			year=0;
		}
		public void setDate(int dd,int mm,int yy)
		{
			day=dd;
			mon=mm;
			year=yy;
		}
		public String dispDate()
		{
			return day+"-"+mon+"-"+year;
		}
	}
