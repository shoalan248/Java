package com.cg.eis.service;

public interface Service
{
	public void findInsuranceScheme(float empSal, String empDesign);
		
}

