package com.cg.eis.pl;
import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class TestEmployee
{
	
public static void main(String args[])
{
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the Employee ID: ");
	int eId=scan.nextInt();
	System.out.println("Enter the Employee Name: ");
	String eName=scan.next();
	System.out.println("Enter the Employee's Salary: ");
	float eSal=scan.nextFloat();
	System.out.println("Enter the Employee Design: ");
	String eDesign=scan.next();

	Employee io=new Employee(eId,eName,eSal,eDesign); 
	
	System.out.println(io.dispInfo());
	
	io.findInsuranceScheme(eSal, eDesign);
	scan.close();
}
}