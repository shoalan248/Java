function calcElecBill(){
cons1=document.getElementById("consno");
cons2=document.getElementById("consnm");
cons3=document.getElementById("consem");
cons4=document.getElementById("consnu");
nam=cons2.value;
em=cons3.value;
no=parseInt(cons1.value);
nu=parseFloat(cons4.value);
if (nu>0 && nu<=100){
elecChrg=nu*2.96;
}
else
{
elecChrg=nu*5.56;
}
alert("Consumer Number:"+no+"Consumer Name:"+nam+"Email ID:"+em+"Unit Consumed:"+nu+"Electric Charge:"+elecChrg);
}
